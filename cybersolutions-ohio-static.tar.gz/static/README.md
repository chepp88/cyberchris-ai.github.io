# CyberSolutionsOhio - Pure HTML/CSS/JavaScript Website

This is a standalone, static website built with pure HTML, CSS, and JavaScript (no frameworks required). It features a synthwave/cyberpunk aesthetic with interactive flip cards, theme switching, and smooth animations.

## 📁 File Structure

```
static/
├── index.html          # Home page with hero section and offerings
├── services.html       # Services page with 10 flip card services
├── about.html          # About Chris Heppard
├── apps.html           # Software suite placeholder
├── blog.html           # Blog placeholder
├── contact.html        # Contact information
├── styles.css          # Complete stylesheet with animations
├── script.js           # JavaScript for interactivity
└── README.md           # This file
```

## 🚀 How to Use

### Option 1: Direct File Access
Simply open `index.html` in your web browser. All pages are fully functional with no build process required.

```bash
# On macOS
open static/index.html

# On Linux
xdg-open static/index.html

# On Windows
start static/index.html
```

### Option 2: Local Web Server
For best results, serve the files through a local web server:

```bash
# Using Python 3
cd static
python3 -m http.server 8000

# Using Python 2
python -m SimpleHTTPServer 8000

# Using Node.js (if installed)
npx http-server static -p 8000

# Using PHP
cd static
php -S localhost:8000
```

Then visit `http://localhost:8000` in your browser.

### Option 3: Deploy to Web Hosting
Upload all files in the `static/` directory to your web hosting provider:
- Netlify (drag and drop)
- GitHub Pages
- Vercel
- Traditional FTP hosting
- Any static file hosting service

## ✨ Features

### Interactive Flip Cards
- Click any service card to flip and reveal the full description
- Smooth 3D flip animation with 500ms transition
- Front side shows icon, title, and hint
- Back side shows detailed description
- Staggered animation on page load (50ms delay between cards)

### Theme Switching
- Toggle between dark and light themes
- Persistent theme preference (saved to localStorage)
- Animated sun/moon icon (3s continuous spin)
- Prominent button with cyan/magenta gradient
- Tooltip showing current theme
- Dual glow effects on hover

### Wow-Factor Animations
- **Floating Animation**: Profile image gently bounces up and down
- **Pulse Glow**: Cards and CTA sections pulse with neon glow
- **Slide-Up**: Cards animate in from bottom on page load
- **Shimmer**: Subtle shimmer effect on hover
- **Scale**: Cards scale up 1.02x on hover for depth
- **Grid Background**: Animated perspective grid background

### Responsive Design
- Mobile-first approach
- Hamburger menu on mobile (< 768px)
- Optimized for all screen sizes
- Touch-friendly buttons and links

## 🎨 Customization

### Change Colors
Edit the CSS variables in `styles.css`:

```css
:root {
    --neon-cyan: oklch(0.85 0.18 195);
    --neon-magenta: oklch(0.7 0.3 330);
    --neon-yellow: oklch(0.95 0.2 100);
    --deep-violet: oklch(0.15 0.08 290);
    --midnight-blue: oklch(0.2 0.1 260);
}
```

### Add More Services
Edit `script.js` and add items to the `offerings` array:

```javascript
const offerings = [
    {
        icon: '<svg>...</svg>',
        title: 'Service Name',
        description: 'Service description here'
    },
    // Add more items
];
```

### Change Fonts
Update the Google Fonts link in HTML files:

```html
<link href="https://fonts.googleapis.com/css2?family=YourFont:wght@400;700&display=swap" rel="stylesheet">
```

### Modify Animations
Edit keyframes in `styles.css`:

```css
@keyframes float {
    0%, 100% {
        transform: translateY(0px);
    }
    50% {
        transform: translateY(-20px);
    }
}
```

## 📱 Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Mobile)

## ⚡ Performance

- **No dependencies**: Pure HTML/CSS/JavaScript
- **Fast loading**: Minimal file sizes
- **Smooth animations**: GPU-accelerated CSS transforms
- **Responsive**: Mobile-optimized
- **Accessible**: Semantic HTML, ARIA labels

## 🔧 JavaScript Classes

### ThemeManager
Handles theme switching and persistence:
```javascript
const themeManager = new ThemeManager();
themeManager.toggleTheme();
themeManager.applyTheme('light');
```

### FlipCard
Creates interactive flip card components:
```javascript
const card = new FlipCard(data, index);
card.toggle(); // Flip the card
```

### NavigationManager
Manages navigation and mobile menu:
```javascript
const nav = new NavigationManager();
```

## 📝 Adding New Pages

1. Create a new HTML file (e.g., `portfolio.html`)
2. Copy the header and footer from an existing page
3. Update the navigation links
4. Add your content in the `<main>` section
5. Include `script.js` at the bottom

## 🎯 SEO Optimization

- Semantic HTML structure
- Meta tags for social sharing
- Descriptive page titles
- Alt text for images
- Proper heading hierarchy

## 📄 License

This website is provided as-is for CyberSolutionsOhio.

## 🤝 Support

For customization or issues, refer to the inline comments in the code or modify the files directly.

---

**Happy coding! 🚀**
