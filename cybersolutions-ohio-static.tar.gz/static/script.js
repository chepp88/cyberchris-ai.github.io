/* ============================================
   CyberSolutionsOhio - Main JavaScript
   ============================================ */

// ============================================
// Data
// ============================================

const offerings = [
    {
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="flip-card-icon"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4m0 6l-4 4m-4-4l-4-4m4 4l4 4" /></svg>',
        title: 'Web Development',
        description: 'Building responsive, high-performance websites from the ground up with modern frameworks and best practices.'
    },
    {
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="flip-card-icon"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>',
        title: 'Cybersecurity Audits',
        description: 'Identifying and mitigating vulnerabilities to protect your digital assets with comprehensive security assessments.'
    },
    {
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="flip-card-icon"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>',
        title: 'Cloud Solutions',
        description: 'Leveraging cloud infrastructure for scalability and efficiency with AWS, Azure, and Google Cloud platforms.'
    },
    {
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="flip-card-icon"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" /></svg>',
        title: 'UI/UX Design',
        description: 'Creating intuitive and engaging user experiences with modern design principles and user-centered approaches.'
    },
    {
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="flip-card-icon"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m7.5-4.5a10.5 10.5 0 11-21 0 10.5 10.5 0 0121 0z" /></svg>',
        title: 'Penetration Testing',
        description: 'Simulating real-world attacks to find security weaknesses before malicious actors can exploit them.'
    },
    {
        icon: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="flip-card-icon"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>',
        title: 'DevOps & Automation',
        description: 'Streamlining development and deployment pipelines with CI/CD, containerization, and infrastructure as code.'
    }
];

// ============================================
// Theme Management
// ============================================

class ThemeManager {
    constructor() {
        this.currentTheme = this.getStoredTheme() || 'dark';
        this.init();
    }

    init() {
        this.applyTheme(this.currentTheme);
        this.setupEventListeners();
    }

    getStoredTheme() {
        return localStorage.getItem('theme') || null;
    }

    applyTheme(theme) {
        this.currentTheme = theme;
        
        if (theme === 'light') {
            document.body.classList.add('light');
        } else {
            document.body.classList.remove('light');
        }

        localStorage.setItem('theme', theme);
        this.updateThemeUI();
    }

    toggleTheme() {
        const newTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
        this.applyTheme(newTheme);
    }

    updateThemeUI() {
        const themeToggle = document.getElementById('theme-toggle');
        const themeIcon = document.getElementById('theme-icon');
        const themeText = document.getElementById('theme-text');
        const themeTooltip = document.getElementById('theme-tooltip');

        if (!themeToggle) return;

        if (this.currentTheme === 'light') {
            themeText.textContent = 'DARK';
            themeTooltip.textContent = 'Switch to Dark Mode';
            // Change icon to moon
            themeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 015.646 5.646 9.003 9.003 0 0015.354 15.354z" />';
        } else {
            themeText.textContent = 'LIGHT';
            themeTooltip.textContent = 'Switch to Light Mode';
            // Change icon to sun
            themeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1m-16 0H1m15.364 1.636l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />';
        }
    }

    setupEventListeners() {
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }
    }
}

// ============================================
// Flip Card Component
// ============================================

class FlipCard {
    constructor(data, index) {
        this.data = data;
        this.index = index;
        this.isFlipped = false;
        this.element = this.create();
    }

    create() {
        const card = document.createElement('div');
        card.className = 'flip-card animate-slide-up';
        card.style.animationDelay = `${this.index * 50}ms`;

        card.innerHTML = `
            <div class="flip-card-inner">
                <div class="flip-card-front">
                    ${this.data.icon}
                    <h3 class="flip-card-title">${this.data.title}</h3>
                    <p class="flip-card-hint">Click to learn more</p>
                </div>
                <div class="flip-card-back">
                    <p class="flip-card-description">${this.data.description}</p>
                    <p class="flip-card-hint">Click to flip back</p>
                </div>
            </div>
        `;

        card.addEventListener('click', () => this.toggle());

        return card;
    }

    toggle() {
        this.isFlipped = !this.isFlipped;
        this.element.classList.toggle('flipped');
    }

    getElement() {
        return this.element;
    }
}

// ============================================
// Navigation Management
// ============================================

class NavigationManager {
    constructor() {
        this.mobileMenuBtn = document.getElementById('mobile-menu-btn');
        this.mobileMenu = document.getElementById('mobile-menu');
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.updateActiveLink();
    }

    setupEventListeners() {
        if (this.mobileMenuBtn) {
            this.mobileMenuBtn.addEventListener('click', () => this.toggleMobileMenu());
        }

        // Close mobile menu when clicking on a link
        const mobileLinks = document.querySelectorAll('.nav-link-mobile');
        mobileLinks.forEach(link => {
            link.addEventListener('click', () => this.closeMobileMenu());
        });
    }

    toggleMobileMenu() {
        if (this.mobileMenu) {
            this.mobileMenu.classList.toggle('hidden');
        }
    }

    closeMobileMenu() {
        if (this.mobileMenu) {
            this.mobileMenu.classList.add('hidden');
        }
    }

    updateActiveLink() {
        const currentPage = window.location.pathname.split('/').pop() || 'index.html';
        
        const navLinks = document.querySelectorAll('.nav-link, .nav-link-mobile');
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === currentPage || (currentPage === '' && href === 'index.html')) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }
}

// ============================================
// Offerings Section
// ============================================

class OfferingsSection {
    constructor() {
        this.container = document.getElementById('offerings-grid');
        this.init();
    }

    init() {
        if (this.container) {
            this.renderCards();
        }
    }

    renderCards() {
        offerings.forEach((offering, index) => {
            const flipCard = new FlipCard(offering, index);
            this.container.appendChild(flipCard.getElement());
        });
    }
}

// ============================================
// Scroll Animations
// ============================================

class ScrollAnimations {
    constructor() {
        this.init();
    }

    init() {
        this.observeElements();
    }

    observeElements() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });

        // Observe all elements with animation classes
        document.querySelectorAll('.animate-slide-up, .animate-float').forEach(el => {
            observer.observe(el);
        });
    }
}

// ============================================
// Initialization
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    // Initialize theme manager
    const themeManager = new ThemeManager();

    // Initialize navigation
    const navigationManager = new NavigationManager();

    // Initialize offerings section
    const offeringsSection = new OfferingsSection();

    // Initialize scroll animations
    const scrollAnimations = new ScrollAnimations();

    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});

// ============================================
// Utility Functions
// ============================================

// Add active class to current navigation item
function setActiveNav(page) {
    document.querySelectorAll('.nav-link, .nav-link-mobile').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === page) {
            link.classList.add('active');
        }
    });
}

// Debounce function for resize events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Handle window resize
window.addEventListener('resize', debounce(() => {
    // Add any resize-related logic here
}, 250));
